/**
 * 
 */
/**
 * 
 */
module CofrinhoMoedas {
}